package com.example.tareitagrupalconmapas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Mausoleo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mausoleo);
    }
}